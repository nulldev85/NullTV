# Changelog

## 0.1.0 — 2026-10-11

### Milestone 1 — Sources and Live TV

- Created native ARM64 WinUI 3 app and thin libmpv C ABI wrapper with D3D11 playback surfaces.
- Implemented playlist and Xtream source import, DPAPI persistence, cached catalogs and Live TV controls.
- Verified upstream ARM64 libmpv asset checksum and fixed URL percent-encoding, XMLTV timezone validation, and malformed-input recovery.
- Core tests: 19/19 passing; synthetic 50,000-channel playlist parsed in 328 ms on the development ARM64 machine.
- Native build and playback verification results are appended after successful runs.

### Milestone 2 — Guide, libraries and settings

- Added XMLTV programme grid, details, reminders and provider-checked catch-up.
- Added VOD/series metadata, episodes, local resume and watched state.
- Added Jellyfin/Emby and Plex PIN connector UI, direct-play URLs and watched-state sync.
- Added multiview, PiP, encrypted backups, sanitized diagnostics, per-profile parental restrictions and settings forms.
- Provider and media-server integration awaits user-supplied sources; fixtures are synthetic.

### Milestone 3 — Distribution

- Added deterministic ARM64 publish script, dependency checksum lock, PE validation and GitHub Actions workflow.
- Added optional MSIX packaging and documented unsigned-package installation limits.
- Added README, feature matrix, license notices and bug-report template.
