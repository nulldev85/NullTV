using Microsoft.UI.Xaml;
using NullTV.Core;

namespace NullTV.App;
public partial class App : Application
{
    public static MainWindow? Main { get; private set; }
    public App() { InitializeComponent(); UnhandledException += (_,e) => { _ = new SafeLog(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"NullTV","logs")).WriteAsync("UNHANDLED",e.Exception); }; }
    protected override void OnLaunched(LaunchActivatedEventArgs args) { Main = new MainWindow(); Main.Activate(); }
}
