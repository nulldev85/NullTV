using System.Net;
using Microsoft.UI;
using Microsoft.UI.Windowing;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Input;
using Microsoft.UI.Xaml.Media;
using NullTV.Core;
using NullTV.App.Playback;
using Windows.System;
using Windows.System.Power;

namespace NullTV.App;
public sealed partial class MainWindow : Window
{
    private readonly HttpClient http=new(new HttpClientHandler { AutomaticDecompression=DecompressionMethods.All }) { Timeout=TimeSpan.FromSeconds(40) };
    private readonly SettingsStore store;
    private readonly SafeLog log;
    private Settings settings=new();
    private readonly CancellationTokenSource lifetime=new();
    private readonly SemaphoreSlim refreshGate=new(1);
    private readonly Dictionary<string,Catalog> catalogs=[];
    private readonly Dictionary<string,List<Programme>> epgs=[];
    private List<MediaItem> items=[];
    private readonly Grid root=new();
    private readonly Grid pageHost=new();
    private readonly StackPanel navigation=new() { Orientation=Orientation.Horizontal, Spacing=8 };
    private readonly TextBlock status=new() { Text="Starting NullTV…", TextWrapping=TextWrapping.Wrap, FontSize=12, Opacity=.75 };
    private readonly TextBlock profileLabel=new();
    private Grid? livePage;
    private string currentTab="Live TV";
    private readonly DispatcherTimer timer=new() { Interval=TimeSpan.FromSeconds(1) };
    private int ticks;
    private bool busy;
    private bool closed;
    private bool closingConfirmed;
    private ImageCache? imageCache;
    private DateTimeOffset lastInput=DateTimeOffset.UtcNow;
    private DateTimeOffset unlockedUntil;
    private int dialogDepth;
    private bool validationFailed;
    public MainWindow()
    {
        Title="NullTV";
        var args=Environment.GetCommandLineArgs();
        var dataIndex=Array.IndexOf(args,"--data-dir");
        var data=dataIndex>=0 && dataIndex+1<args.Length ? args[dataIndex+1] : Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"NullTV");
        store=new(data); log=new(Path.Combine(data,"logs"));
        ExtendsContentIntoTitleBar=true;
        root.RowDefinitions.Add(new() { Height=new(48) }); root.RowDefinitions.Add(new() { Height=new(62) }); root.RowDefinitions.Add(new() { Height=new(1,GridUnitType.Star) }); root.RowDefinitions.Add(new() { Height=GridLength.Auto });
        var titlebar=new Grid { Padding=new Thickness(24,0,150,0) }; titlebar.ColumnDefinitions.Add(new() { Width=new(1,GridUnitType.Star) }); titlebar.ColumnDefinitions.Add(new() { Width=GridLength.Auto });
        var brand=new TextBlock { Text="◉  NULLTV", FontSize=15, FontWeight=Microsoft.UI.Text.FontWeights.SemiBold, CharacterSpacing=160, VerticalAlignment=VerticalAlignment.Center }; titlebar.Children.Add(brand);
        profileLabel.Text="ARM64 · YOUR SCREEN, YOUR SOURCES"; profileLabel.FontSize=11; profileLabel.Opacity=.65; profileLabel.VerticalAlignment=VerticalAlignment.Center; Grid.SetColumn(profileLabel,1); titlebar.Children.Add(profileLabel);
        root.Children.Add(titlebar); SetTitleBar(titlebar);
        navigation.Margin=new Thickness(24,4,24,12); Grid.SetRow(navigation,1); root.Children.Add(navigation);
        foreach(var name in new[] { "Live TV","Guide","Movies & Series","Media Servers","Settings" }) navigation.Children.Add(Button(name,()=>Navigate(name)));
        pageHost.Margin=new Thickness(24,0,24,16); Grid.SetRow(pageHost,2); root.Children.Add(pageHost);
        status.Margin=new Thickness(24,0,24,12); Grid.SetRow(status,3); root.Children.Add(status);
        root.KeyDown+=OnKey;
        root.PointerMoved+=(_,_)=>lastInput=DateTimeOffset.UtcNow;
        root.SizeChanged+=(_,_)=> { if(livePage==null || fullscreen) return; livePage.ColumnDefinitions[0].Width=new(root.ActualWidth<1050 ? 0 : 170); livePage.ColumnDefinitions[1].Width=new(root.ActualWidth<800 ? 220 : 280); };
        Content=root;
        AppWindow.Resize(new Windows.Graphics.SizeInt32(1440,960));
        AppWindow.Changed+=(_,_)=> { if(surface!=null) surface.Hide(currentTab!="Live TV" || !AppWindow.IsVisible); };
        Closed+=(_,_)=> { closed=true; lifetime.Cancel(); timer.Stop(); foreach(var s in surfaces) s.Dispose(); pipWindow?.Close(); _=store.SaveAsync(settings); http.Dispose(); };
        AppWindow.Closing+=async (_,e)=> { if(closingConfirmed) return; e.Cancel=true; timer.Stop(); await GuardAsync(SaveProgressAsync); closingConfirmed=true; Close(); };
        root.Loaded+=async (_,_)=>await GuardAsync(InitializeAsync);
        timer.Tick+=async (_,_)=>await TickAsync();
    }
    private async Task InitializeAsync()
    {
        try { settings=await store.LoadAsync(); } catch(Exception e) when(e is System.Security.Cryptography.CryptographicException or System.Text.Json.JsonException or InvalidDataException or IOException) { status.Text="Settings could not be unlocked. Original file is preserved; use Restore Backup in Settings."; await log.WriteAsync("SETTINGS_LOAD_FAILED",e); }
        var display=DisplayArea.GetFromWindowId(AppWindow.Id,DisplayAreaFallback.Primary).WorkArea;
        var dpi=root.XamlRoot.RasterizationScale;
        var width=(int)Math.Min(1280*dpi,display.Width*.94); var height=(int)Math.Min(820*dpi,display.Height*.94);
        AppWindow.MoveAndResize(new Windows.Graphics.RectInt32(display.X+(display.Width-width)/2,display.Y+(display.Height-height)/2,width,height));
        imageCache=new(http,Path.Combine(store.DirectoryPath,"images"));
        ApplyAppearance(); BuildLive(); Navigate(settings.StartupTab);
        foreach(var s in settings.Profile.Sources) { var cached=await store.LoadCacheAsync(s.Id); if(cached!=null) catalogs[s.Id]=cached; }
        RebuildItems(); await RefreshAllAsync(false); timer.Start();
        var args=Environment.GetCommandLineArgs(); var index=Array.IndexOf(args,"--smoke-video"); var playlistIndex=Array.IndexOf(args,"--smoke-playlist");
        if(playlistIndex>=0 && playlistIndex+1<args.Length && Array.IndexOf(args,"--data-dir")>=0) { var s=new Source { Name="Local validation",Kind=SourceKind.PlaylistFile,Address=args[playlistIndex+1] }; settings.Profile.Sources.Clear(); settings.Profile.Sources.Add(s); await RefreshSourceAsync(s); Navigate("Live TV"); var channel=items.FirstOrDefault(i=>i.Kind==MediaKind.Live); if(channel!=null) await PlayAsync(channel); }
        else if(index>=0 && index+1<args.Length) { Navigate("Live TV"); await PlayAsync(new("smoke","smoke","Local generated validation clip","Validation",MediaKind.Movie,args[index+1])); }
        else if(settings.ResumeOnLaunch) { var last=settings.Profile.History.OrderByDescending(x=>x.Value.Updated).FirstOrDefault(); var media=items.FirstOrDefault(i=>i.Id==last.Key && i.Kind!=MediaKind.Series); if(media!=null) await PlayAsync(media); }
        var tabIndex=Array.IndexOf(args,"--smoke-tab"); if(tabIndex>=0 && tabIndex+1<args.Length) Navigate(args[tabIndex+1]);
        var secondsIndex=Array.IndexOf(args,"--smoke-seconds");
        if(secondsIndex>=0 && secondsIndex+1<args.Length && int.TryParse(args[secondsIndex+1],out var seconds) && seconds is >=2 and <=60 && Array.IndexOf(args,"--data-dir")>=0)
        {
            var end=new DispatcherTimer { Interval=TimeSpan.FromSeconds(seconds) }; end.Tick+=async (_,_)=> { end.Stop(); Directory.CreateDirectory(store.DirectoryPath); await File.WriteAllTextAsync(Path.Combine(store.DirectoryPath,"ui-validation.json"),System.Text.Json.JsonSerializer.Serialize(new { View=currentTab,Passed=!validationFailed,Width=root.ActualWidth,Height=root.ActualHeight,NativePlayer=surface?.Player!=null,Architecture=System.Runtime.InteropServices.RuntimeInformation.ProcessArchitecture.ToString() })); closingConfirmed=true; await store.SaveAsync(settings); Close(); }; end.Start();
        }
    }
    private void ApplyAppearance()
    {
        root.RequestedTheme=settings.Appearance.Theme=="Light" ? ElementTheme.Light : ElementTheme.Dark;
        root.Background=new SolidColorBrush(settings.Appearance.Theme=="OLED" ? Colors.Black : settings.Appearance.Theme=="Light" ? Color("#F4F6F7") : Color("#10151B"));
        if(settings.Appearance.Mica && settings.Appearance.Theme!="OLED") { root.Background=null; SystemBackdrop=new MicaBackdrop(); } else SystemBackdrop=null;
        root.Resources["SystemAccentColor"]=Color(settings.Appearance.Accent);
        root.Resources["ListViewItemBackgroundSelected"]=new SolidColorBrush(Color(settings.Appearance.Accent));
        root.Resources["ListViewItemForegroundSelected"]=new SolidColorBrush(Colors.Black);
        root.Resources["ControlMinHeight"]=44d;
        profileLabel.Text=$"{settings.Profile.Name.ToUpperInvariant()}  ·  NATIVE ARM64";
    }
    private static Windows.UI.Color Color(string hex) { try { hex=hex.TrimStart('#'); if(hex.Length==6) return Windows.UI.Color.FromArgb(255,Convert.ToByte(hex[..2],16),Convert.ToByte(hex[2..4],16),Convert.ToByte(hex[4..6],16)); if(hex.Length==8) return Windows.UI.Color.FromArgb(Convert.ToByte(hex[..2],16),Convert.ToByte(hex[2..4],16),Convert.ToByte(hex[4..6],16),Convert.ToByte(hex[6..8],16)); } catch(FormatException) { } return Colors.MediumAquamarine; }
    private Button Button(string label,Action action) { var b=new Button { Content=label,MinHeight=44,CornerRadius=new CornerRadius(8),Padding=new Thickness(16,8,16,8) }; b.Click+=async (_,_)=> { lastInput=DateTimeOffset.UtcNow; await GuardAsync(()=> { action(); return Task.CompletedTask; }); }; return b; }
    private Button AsyncButton(string label,Func<Task> action) => Button(label,()=>_=GuardAsync(action));
    private async Task GuardAsync(Func<Task> action)
    {
        try { await action(); } catch(OperationCanceledException) { if(!closed) status.Text="Operation cancelled or timed out."; } catch(Exception e) when(e is not OutOfMemoryException) { validationFailed=true; await log.WriteAsync("ACTION_FAILED",e); if(!closed) status.Text=Friendly(e); }
    }
    public void ReportUnhandled(Exception e) { validationFailed=true; _=log.WriteAsync("UI_FAILED",e); status.Text="This operation could not complete. Try another view or export Diagnostics. Your settings are preserved."; }
    private void ValidationStep(string code) { if(!Environment.GetCommandLineArgs().Contains("--smoke-tab")) return; Directory.CreateDirectory(store.DirectoryPath); File.AppendAllText(Path.Combine(store.DirectoryPath,"validation.log"),code+"\n"); }
    private static string Friendly(Exception e) => e is InvalidDataException ? e.Message : e is HttpRequestException ? "The server could not be reached. Check the address and connection; cached channels remain available." : e is IOException ? "The file could not be read or written. Check its location and permissions." : e is System.Security.Cryptography.CryptographicException ? "The password is incorrect, or this encrypted file is damaged." : "The operation failed. Export Diagnostics for its error type; credentials are excluded.";
    private TextBlock Text(string value,int size=14) => new() { Text=value,FontSize=size*settings.Appearance.FontScale,TextWrapping=TextWrapping.Wrap };
    private StackPanel Stack(params UIElement[] children) { var p=new StackPanel { Spacing=12 }; foreach(var c in children) p.Children.Add(c); return p; }
    private static void Place(Grid g,UIElement c,int row=0,int col=0) { Grid.SetRow((FrameworkElement)c,row); Grid.SetColumn((FrameworkElement)c,col); g.Children.Add(c); }
    private static TextBox Field(string label,string value="") => new() { Header=label,Text=value,MinHeight=44 };
    private static ComboBox Choice(string label,IEnumerable<string> values,string selected) { var c=new ComboBox { Header=label,MinHeight=44,HorizontalAlignment=HorizontalAlignment.Stretch }; foreach(var v in values) c.Items.Add(v); c.SelectedItem=selected; if(c.SelectedIndex<0 && c.Items.Count>0) c.SelectedIndex=0; return c; }
    private static ToggleSwitch Toggle(string label,bool value) => new() { Header=label,IsOn=value,MinHeight=44 };
    private ScrollViewer Scroll(UIElement element) => new() { Content=element,VerticalScrollBarVisibility=ScrollBarVisibility.Auto,HorizontalScrollBarVisibility=ScrollBarVisibility.Disabled };
    private void Navigate(string tab)
    {
        currentTab=tab; foreach(var s in surfaces) s.Hide(tab!="Live TV");
        foreach(var b in navigation.Children.OfType<Button>()) { var selected=(string)b.Content==tab; b.Opacity=selected ? 1 : .75; b.Background=new SolidColorBrush(selected ? Color(settings.Appearance.Accent) : Color(settings.Appearance.Theme=="Light" ? "#E1E5E8" : "#171D23")); b.Foreground=new SolidColorBrush(selected || settings.Appearance.Theme=="Light" ? Colors.Black : Colors.White); }
        foreach(var child in pageHost.Children) child.Visibility=Visibility.Collapsed;
        if(tab=="Live TV") { if(livePage!=null) livePage.Visibility=Visibility.Visible; foreach(var s in surfaces) s.Hide(false); return; }
        // Other pages are rebuilt to reflect profile and settings changes.
        foreach(var child in pageHost.Children.Where(c=>c!=livePage).ToArray()) pageHost.Children.Remove(child);
        pageHost.Children.Add(tab switch { "Guide"=>BuildGuide(), "Movies & Series"=>BuildLibrary(), "Media Servers"=>BuildServers(), _=>BuildSettings() });
    }
    private void RebuildItems() { int number=0; items=settings.Profile.Sources.SelectMany(s=>catalogs.GetValueOrDefault(s.Id)?.Items??[]).Select(i=>i.Kind==MediaKind.Live ? i with { Number=++number } : i).ToList(); foreach(var catalog in catalogs.Values) foreach(var (id,remote) in catalog.RemoteHistory) { if(!settings.Profile.History.TryGetValue(id,out var local) || remote.Updated>local.Updated) settings.Profile.History[id]=remote; } UpdateLive(); }
    private async Task RefreshAllAsync(bool force)
    {
        if(!await refreshGate.WaitAsync(0)) return;
        try
        {
            busy=true;
            foreach(var s in settings.Profile.Sources.Where(s=>s.Kind is SourceKind.Xtream or SourceKind.PlaylistFile or SourceKind.PlaylistUrl))
            {
                if(!force && catalogs.ContainsKey(s.Id) && DateTimeOffset.UtcNow-s.LastRefresh<TimeSpan.FromHours(s.RefreshHours)) continue;
                await GuardAsync(async ()=> { status.Text=$"Refreshing {s.Name}…"; var service=new SourceService(http,store); var catalog=await Task.Run(()=>service.RefreshAsync(s,lifetime.Token)); catalogs[s.Id]=catalog; RebuildItems(); await store.SaveAsync(settings); try { epgs[s.Id]=await Task.Run(()=>service.LoadEpgAsync(s,catalog,lifetime.Token)); } catch(Exception e) { status.Text="Channels loaded. EPG unavailable; set an XMLTV override in Sources."; await log.WriteAsync("EPG_FAILED",e); } });
            }
            UpdateLive(); if(!settings.Profile.Sources.Any()) status.Text="Welcome. Add your provider or playlist in Settings → Sources to get started.";
            else status.Text=$"{items.Count:N0} items · {settings.Profile.Sources.Count} sources · {epgs.Values.Sum(x=>x.Count):N0} guide programmes";
        }
        finally { busy=false; refreshGate.Release(); }
    }
    private async Task TickAsync()
    {
        ticks++; PollController();
        if(surface?.Player!=null && playing!=null && ticks%5==0) await GuardAsync(SaveProgressAsync);
        if(ticks%15==0 && playing!=null) _=GuardAsync(SyncServerProgressAsync);
        if(fullscreen && playerControls!=null) playerControls.Visibility=DateTimeOffset.UtcNow-lastInput>TimeSpan.FromSeconds(4) ? Visibility.Collapsed : Visibility.Visible;
        if(ticks%60==0)
        {
            if(PowerManager.EnergySaverStatus!=EnergySaverStatus.On && !busy) _=GuardAsync(()=>RefreshAllAsync(false));
            var due=settings.Profile.Reminders.Where(r=>r.Start<=DateTimeOffset.UtcNow && r.Start>DateTimeOffset.UtcNow.AddMinutes(-2)).ToList();
            foreach(var r in due) { settings.Profile.Reminders.Remove(r); status.Text=$"Reminder: {r.Title} starts now."; }
            if(due.Count>0) await store.SaveAsync(settings);
            UpdateLive();
        }
    }
    private async Task<ContentDialogResult> DialogAsync(string title,UIElement content,string primary="Save")
    {
        dialogDepth++; foreach(var s in surfaces) s.Hide(true);
        try { return await new ContentDialog { Title=title,Content=content,PrimaryButtonText=primary,CloseButtonText="Cancel",DefaultButton=ContentDialogButton.Primary,XamlRoot=root.XamlRoot,RequestedTheme=root.RequestedTheme }.ShowAsync(); }
        finally { dialogDepth--; if(currentTab=="Live TV" && dialogDepth==0) foreach(var s in surfaces) s.Hide(false); }
    }
    private async Task<bool> UnlockAsync(MediaItem item)
    {
        var p=settings.Profile;
        if(!p.LockedItems.Contains(item.Id) && !p.LockedCategories.Contains(item.Category) || DateTimeOffset.UtcNow<unlockedUntil) return true;
        if(p.PinHash=="") { status.Text="Set a parental PIN in Settings before unlocking this item."; return false; }
        var pin=new PasswordBox { Header="Parental PIN",MinHeight=44 };
        if(await DialogAsync("Unlock playback",pin,"Unlock")!=ContentDialogResult.Primary) return false;
        if(!await Task.Run(()=>SecretStore.CheckPin(pin.Password,p))) { status.Text="Incorrect parental PIN."; return false; }
        unlockedUntil=DateTimeOffset.UtcNow.AddMinutes(settings.LockTimeoutMinutes); return true;
    }
}
